import Activities from './scenes/Activitities'
import 'bootstrap/dist/css/bootstrap.min.css'

function App() {
  return (
    <Activities />
  )
}

export default App
